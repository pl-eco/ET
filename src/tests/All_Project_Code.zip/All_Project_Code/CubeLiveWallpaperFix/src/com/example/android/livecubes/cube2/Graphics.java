package com.example.android.livecubes.cube2;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.SurfaceHolder;

class Graphics @phase(graphics) {
    	
    	private final Paint mPaint = new Paint();
    	
    	CubeEngine @phase(main) cubeEngine;
    	
    	Graphics(CubeEngine cubeEng){
    		
    		// Create a Paint to draw the lines for our cube
            final Paint paint = mPaint;
            paint.setColor(0xffffffff);
            paint.setAntiAlias(true);
            paint.setStrokeWidth(2);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStyle(Paint.Style.STROKE);
    		
    		cubeEngine = cubeEng;
    	}
    	
    	/*
         * Draw one frame of the animation. This method gets called repeatedly
         * by posting a delayed Runnable. You can do any drawing you want in
         * here. This example draws a wireframe cube.
         */
        void drawFrame() {
        	
            final SurfaceHolder holder = (adapt cubeEngine).getSurfaceHolder();
            final Rect frame = holder.getSurfaceFrame();
            final int width = frame.width();
            final int height = frame.height();

            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) {
                    // draw something
                    drawCube(c);
                    drawTouchPoint(c);
                }
            } finally {
                if (c != null) holder.unlockCanvasAndPost(c);
            }

            (adapt cubeEngine).mHandler.removeCallbacks((adapt cubeEngine).mDrawCube);
            if ((adapt cubeEngine).mVisible) {
				(adapt cubeEngine).mHandler.postDelayed((adapt cubeEngine).mDrawCube, 25);
            }
		}
        
        void drawCube(Canvas c) {
            c.save();
            c.translate(cubeEngine.mCenterX, cubeEngine.mCenterY);
            c.drawColor(0xff000000);

            long now = SystemClock.elapsedRealtime();
            float xrot = ((float)(now - cubeEngine.mStartTime)) / 1000;
            float yrot = (0.5f - cubeEngine.mOffset) * 2.0f;
            rotateAndProjectPoints(xrot, yrot);
            drawLines(c);
            c.restore();
        }
        
        void drawTouchPoint(Canvas c) {
            if (cubeEngine.mTouchX >=0 && cubeEngine.mTouchY >= 0) {
                c.drawCircle(cubeEngine.mTouchX, cubeEngine.mTouchY, 80, mPaint);
            }
        }
        
        void rotateAndProjectPoints(float xrot, float yrot) {
            int n = cubeEngine.mOriginalPoints.length;
            for (int i = 0; i < n; i++) {
                // rotation around X-axis
                ThreeDPoint p = cubeEngine.mOriginalPoints[i];
                float x = p.x;
                float y = p.y;
                float z = p.z;
                float newy = (float)(Math.sin(xrot) * z + Math.cos(xrot) * y);
                float newz = (float)(Math.cos(xrot) * z - Math.sin(xrot) * y);

                // rotation around Y-axis
                float newx = (float)(Math.sin(yrot) * newz + Math.cos(yrot) * x);
                newz = (float)(Math.cos(yrot) * newz - Math.sin(yrot) * x);

                // 3D-to-2D projection
                float screenX = newx / (4 - newz / 400);
                float screenY = newy / (4 - newz / 400);

                cubeEngine.mRotatedPoints[i].x = screenX;
                cubeEngine.mRotatedPoints[i].y = screenY;
                cubeEngine.mRotatedPoints[i].z = 0;
            }
        }
        
        void drawLines(Canvas c) {
            int n = cubeEngine.mLines.length;
            for (int i = 0; i < n; i++) {
                ThreeDLine l = cubeEngine.mLines[i];
                ThreeDPoint start = cubeEngine.mRotatedPoints[l.startPoint];
                ThreeDPoint end = cubeEngine.mRotatedPoints[l.endPoint];
                c.drawLine(start.x, start.y, end.x, end.y, mPaint);
            }
        }
    }