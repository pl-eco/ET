package com.example.android.livecubes.cube2;

import java.util.Calendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService.Engine;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.widget.Toast;


phases {graphics <cpu main;}
modes {lofi <: hifi;}

    class CubeEngine extends Engine 
        implements SharedPreferences.OnSharedPreferenceChangeListener {
    	
    	//time testing
    	long milis = 0;
    	int timeCount = 0;
    	
    	Context mContext;
    	
    	public static final String SHARED_PREFS_NAME="cube2settings";
    	
    	Graphics@phase(graphics) graphics;
    	
    	CubeWallpaper2 cubeWallpaper2;

        final Handler mHandler = new Handler();

        ThreeDPoint [] mOriginalPoints;
        ThreeDPoint [] mRotatedPoints;
        ThreeDLine [] mLines;
        
        float mOffset;
        float mTouchX = -1;
        float mTouchY = -1;
        long mStartTime;
        float mCenterX;
        float mCenterY;

        final Runnable mDrawCube = new Runnable() {
            public void run() {
                (adapt graphics).drawFrame();
                
                if (timeCount == 0)
                	milis = Calendar.getInstance().getTimeInMillis();
			
                	timeCount++;
			
                if (timeCount == 1667){
                	milis = Calendar.getInstance().getTimeInMillis() - milis;
                	Toast.makeText(cubeWallpaper2, String.valueOf(milis), Toast.LENGTH_SHORT).show();
                	timeCount = 0;
                }
            }
        };
        boolean mVisible;
        private SharedPreferences mPrefs;

        CubeEngine(CubeWallpaper2 cubeWall) {
            cubeWall.super();
        	
            cubeWallpaper2 = cubeWall;

            mStartTime = SystemClock.elapsedRealtime();

            mPrefs = cubeWallpaper2.getSharedPreferences(SHARED_PREFS_NAME, 0);
            mPrefs.registerOnSharedPreferenceChangeListener(this);
            onSharedPreferenceChanged(mPrefs, null);
            
            graphics = new Graphics(this);
        }

        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {

            String shape = prefs.getString("cube2_shape", "cube");

            // read the 3D model from the resource
            readModel(shape);
        }

        private void readModel(String prefix) {
            // Read the model definition in from a resource.

            // get the resource identifiers for the arrays for the selected shape
            int pid = cubeWallpaper2.getResources().getIdentifier(prefix + "points", "array", cubeWallpaper2.getPackageName());
            int lid = cubeWallpaper2.getResources().getIdentifier(prefix + "lines", "array", cubeWallpaper2.getPackageName());

            String [] p = cubeWallpaper2.getResources().getStringArray(pid);
            int numpoints = p.length;
            mOriginalPoints = new ThreeDPoint[numpoints];
            mRotatedPoints = new ThreeDPoint[numpoints];

            for (int i = 0; i < numpoints; i++) {
                mOriginalPoints[i] = new ThreeDPoint();
                mRotatedPoints[i] = new ThreeDPoint();
                String [] coord = p[i].split(" ");
                mOriginalPoints[i].x = Float.valueOf(coord[0]);
                mOriginalPoints[i].y = Float.valueOf(coord[1]);
                mOriginalPoints[i].z = Float.valueOf(coord[2]);
            }

            String [] l = cubeWallpaper2.getResources().getStringArray(lid);
            int numlines = l.length;
            mLines = new ThreeDLine[numlines];

            for (int i = 0; i < numlines; i++) {
                mLines[i] = new ThreeDLine();
                String [] idx = l[i].split(" ");
                mLines[i].startPoint = Integer.valueOf(idx[0]);
                mLines[i].endPoint = Integer.valueOf(idx[1]);
            }
        }

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            setTouchEventsEnabled(true);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            mHandler.removeCallbacks(mDrawCube);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            mVisible = visible;
            if (visible) {
            	(adapt graphics).drawFrame();
            } else {
                mHandler.removeCallbacks(mDrawCube);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            // store the center of the surface, so we can draw the cube in the right spot
            mCenterX = width/2.0f;
            mCenterY = height/2.0f;
            (adapt graphics).drawFrame();
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            mVisible = false;
            mHandler.removeCallbacks(mDrawCube);
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset,
                float xStep, float yStep, int xPixels, int yPixels) {
            mOffset = xOffset;
			(adapt graphics).drawFrame();
        }

        /*
         * Store the position of the touch event so we can use it for drawing later
         */
        @Override
        public void onTouchEvent(MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                mTouchX = event.getX();
                mTouchY = event.getY();
            } else {
                mTouchX = -1;
                mTouchY = -1;
            }
            super.onTouchEvent(event);
        }                
    }