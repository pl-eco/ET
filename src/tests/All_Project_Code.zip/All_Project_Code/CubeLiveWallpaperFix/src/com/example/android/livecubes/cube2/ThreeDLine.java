package com.example.android.livecubes.cube2;

class ThreeDLine {
        int startPoint;
        int endPoint;
}