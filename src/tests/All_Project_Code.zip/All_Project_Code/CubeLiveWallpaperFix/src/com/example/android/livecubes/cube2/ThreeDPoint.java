package com.example.android.livecubes.cube2;

class ThreeDPoint {
        float x;
        float y;
        float z;
}