#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <android/log.h>

#include "com_example_android_livecubes_cube2_utilScale.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "bang_cpufreq", __VA_ARGS__)

JNIEXPORT jint JNICALL Java_com_example_android_livecubes_cube2_utilScale_scale
  (JNIEnv * env, jclass jcls, jstring name){
	jboolean iscopy;
	const char *govFile = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor";
	const char *usrSpace = "userspace";
	const char *filename = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_setspeed";
	const char *freq = (*env)->GetStringUTFChars(env, name, &iscopy);
	
	FILE *f;
    int rc;
    size_t data_length, data_written;
	
	//Read govenor
	f = fopen(govFile, "r");
    if (f == NULL) {
        //LOGI("Failed to open %s: %s", filename, strerror(errno));
		return 1;
    }
	
	char *string = malloc(25);
	
	fscanf (f, "%s", string);

    rc = fclose(f);
    if (rc != 0) {
        //LOGI("Failed to close %s: %s", filename, strerror(rc));
		return 1;
    }
	
	if (strcmp(string, usrSpace) != 0){
		//Write govenor
		f = fopen(govFile, "w");
		if (f == NULL) {
			//LOGI("Failed to open %s: %s", govFile, strerror(errno));
			return 1;
		}

		data_length = strlen(usrSpace);
		data_written = fwrite(usrSpace, 1, data_length, f);
		if (data_length != data_written) {
			//LOGI("Failed to write to %s: %s", filename, strerror(errno));
			return 1;
		}

		rc = fclose(f);
		if (rc != 0) {
			//LOGI("Failed to close %s: %s", filename, strerror(rc));
			return 1;
		}
	}
	
	//free memory
	free (string);

	//Write frequency
    f = fopen(filename, "w");
    if (f == NULL) {
        //LOGI("Failed to open %s: %s", filename, strerror(errno));
        return 1;
    }

    data_length = strlen(freq);
    data_written = fwrite(freq, 1, data_length, f);
    if (data_length != data_written) {
        //LOGI("Failed to write to %s: %s", filename, strerror(errno));
        return 1;
    }

    rc = fclose(f);
    if (rc != 0) {
        //LOGI("Failed to close %s: %s", filename, strerror(rc));
        return 1;
    }

    return 1;
}

JNIEXPORT jobjectArray JNICALL Java_com_example_android_livecubes_cube2_utilScale_freqAvailable
  (JNIEnv * env, jclass jcls){
	const char *filename = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies";
	
	jobjectArray ret;
    int i;
	
	FILE *f;
    int rc;
    size_t data_length, data_written;

    f = fopen(filename, "r");
    if (f == NULL) {
        //LOGI("Failed to open %s: %s", filename, strerror(errno));
    }
	
	char *freq[10];
	char *string;
	int count = 0;
	
	while (fscanf (f, "%s", string) != EOF){
			freq[count] = malloc(25);
			freq[count] = string;
			count++;
		}

    rc = fclose(f);
    if (rc != 0) {
        //LOGI("Failed to close %s: %s", filename, strerror(rc));
    }

    ret= (jobjectArray)(*env)->NewObjectArray(env, count,
         (*env)->FindClass(env, "java/lang/String"),
         (*env)->NewStringUTF(env, ""));

    for(i = 0; i < count; i++) {
        (*env)->SetObjectArrayElement(env,
		ret,i,(*env)->NewStringUTF(env, freq[i]));
		
		//free memory
		free (freq[i]);
    }
	
    return(ret);
}
