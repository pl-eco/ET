#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <android/log.h>

#include "com_example_android_gestures_demo_GesturesActivity.h"
#include "myandroid_gesture_GestureOverlayView.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "bang_cpufreq", __VA_ARGS__)

JNIEXPORT jint JNICALL Java_com_example_android_gestures_demo_GesturesActivity_scale
  (JNIEnv * env, jobject jobj, jstring name) {
	jboolean iscopy;
	const char *filename = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_setspeed";
	const char *freq = (*env)->GetStringUTFChars(env, name, &iscopy);
	
	FILE *f;
    int rc;
    size_t data_length, data_written;

    f = fopen(filename, "w");
    if (f == NULL) {
        //LOGI("Failed to open %s: %s", filename, strerror(errno));
        return 1;
    }

    data_length = strlen(freq);
    data_written = fwrite(freq, 1, data_length, f);
    if (data_length != data_written) {
        //LOGI("Failed to write to %s: %s", filename, strerror(errno));
        return 1;
    }

    rc = fclose(f);
    if (rc != 0) {
        //LOGI("Failed to close %s: %s", filename, strerror(rc));
        return 1;
    }

    return 0;
}

JNIEXPORT jint JNICALL Java_myandorid_gesture_GestureOverlayView_scale2
  (JNIEnv * env, jobject jobj, jstring name) {
	jboolean iscopy;
	const char *filename = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_setspeed";
	const char *freq = (*env)->GetStringUTFChars(env, name, &iscopy);
	
	FILE *f;
    int rc;
    size_t data_length, data_written;

    f = fopen(filename, "w");
    if (f == NULL) {
        //LOGI("Failed to open %s: %s", filename, strerror(errno));
        return 1;
    }

    data_length = strlen(freq);
    data_written = fwrite(freq, 1, data_length, f);
    if (data_length != data_written) {
        //LOGI("Failed to write to %s: %s", filename, strerror(errno));
        return 1;
    }

    rc = fclose(f);
    if (rc != 0) {
        //LOGI("Failed to close %s: %s", filename, strerror(rc));
        return 1;
    }

    return 0;
}
