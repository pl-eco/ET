package com.example.android.gestures.demo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import myandroid.gesture.Gesture;
import myandroid.gesture.GestureLibraries;
import myandroid.gesture.GestureLibrary;
import myandroid.gesture.GestureOverlayView;
import android.content.IntentFilter;
import myandroid.gesture.Prediction;
import myandroid.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.os.Bundle;
import android.widget.Toast;

phases { 
	graphics <cpu main; 
	main <cpu maths;
}

modes {
	hifi <: full;
	lowfi <: hifi;
}

public class GesturesActivity extends Activity implements OnGesturePerformedListener {
    private GestureLibrary@phase(maths)  mLibrary;
    
    public static Intent batteryIntent;
    
	
	long milis;
	int count = 0;
	long times;

	@Override
    public void onCreate(Bundle savedInstanceState) {
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mLibrary = GestureLibraries.fromRawResource(this, R.raw.spells);
        if (!((adapt mLibrary).load())) {
        	finish();
        }

        GestureOverlayView @phase(graphics) gestures = (GestureOverlayView) findViewById(R.id.gestures);
        (adapt gestures).addOnGesturePerformedListener(this);
        
        batteryIntent = getApplicationContext().registerReceiver(null,
	            new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }
	
	public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
		
		if(count == 0)
			milis = Calendar.getInstance().getTimeInMillis();
		
		ArrayList<Prediction> predictions = (adapt mLibrary).recognize(gesture);		

		// We want at least one prediction
		if (predictions.size() > 0) {
			Prediction prediction = predictions.get(0);
			// We want at least some confidence in the result
			if (prediction.score > 1.0) {
				// Show the spell
				Toast.makeText(this, prediction.name, Toast.LENGTH_SHORT).show();
			}
		}
		
		count++;
		
		if (count == 10){
			milis = Calendar.getInstance().getTimeInMillis() - milis;
			Toast.makeText(this, String.valueOf(milis), Toast.LENGTH_SHORT).show();
			count = 0;
		}
	}
	
	public static Intent battery(){
		return batteryIntent;
	}
}