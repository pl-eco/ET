package com.example.android.backuprestore;

import android.content.Intent;
import android.util.Log;

import java.io.IOException;
import java.io.RandomAccessFile;

public class ReaderWriter@phase(rw) {
	
	static final String DATA_FILE_NAME = "saved_data";
	RandomAccessFile file;
    	
	ReaderWriter() {		
		file = new RandomAccessFile(new File(getFilesDir(), DATA_FILE_NAME), "rw"));		
	}	
	
	
	boolean dataExists() {
		return file.exists();
	}
	
	AppData read() {
		int whichFilling = file.readInt();
		boolean addMayo = file.readBoolean();
		boolean addTomato = file.readBoolean();
		return new AppData(whichFilling, addMayo, addTomato);
	}
	
    void writeDataToFileLocked(Appdata appd) throws IOException {
		
            //file.setLength(0L);

            Integer loop_hifi = new @mode(hifi) Integer(20000);
            Integer loop_lofi = new @mode(lofi) Integer(18000);
            
            
            int count = 0;
            mswitch(BackupRestoreActivity.batteryState()){
				case #hifi:
	        		while (count < loop_hifi.intValue()){
	            		file.writeInt(whichFilling);
						file.writeBoolean(appd.addMayo);
						file.writeBoolean(appd.addTomato);
	            		count++;
	            	}
				case #lofi:
	            	while (count < loop_lofi.intValue()){
	            		file.writeInt(whichFilling);
						file.writeBoolean(appd.addMayo);
						file.writeBoolean(appd.addTomato);
	            		count++;
	            	}
	        }
            
            
            Log.v(TAG, "NEW STATE: mayo=" + appd.addMayo
                    + " tomato=" + appd.addTomato
                    + " filling=" + appd.whichFilling);
    }
    
	
}