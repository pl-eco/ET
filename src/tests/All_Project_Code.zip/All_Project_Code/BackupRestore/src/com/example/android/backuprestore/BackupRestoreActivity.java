package com.example.android.backuprestore;

import android.app.Activity;
import android.app.backup.BackupManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import java.util.Calendar;
import java.util.Random;

phases { rw <cpu main; }
modes {hifi <: full; lofi <: hifi; }



public class BackupRestoreActivity extends Activity {
	
	ReaderWriter RWer@phase(rw) = new ReaderWriter();
	
    static final Object[] sDataLock = new Object[0];


    RadioGroup mFillingGroup;
    CheckBox mAddMayoCheckbox;
    CheckBox mAddTomatoCheckbox;

    BackupManager@phase(rw) mBackupManager;

	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);

        setContentView(R.layout.backup_restore);

        mFillingGroup = (RadioGroup) findViewById(R.id.filling_group);
        mAddMayoCheckbox = (CheckBox) findViewById(R.id.mayo);
        mAddTomatoCheckbox = (CheckBox) findViewById(R.id.tomato);
		
        Toast.makeText(BackupRestoreActivity.this, mDataFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();

        mBackupManager = new BackupManager(this);

        populateUI();               
	}

	
	
	
    void populateUI() {

		AppData appd = new AppData(R.id.pastrami, false, false);

		/*
        synchronized (BackupRestoreActivity.sDataLock) {
            try {
                if (RWer.DataExists()) {
					appd = RWer.read();
                } else {
                    RWer.writeDataToFileLocked(appd);
                    mBackupManager.dataChanged();
                }
            } catch (IOException ioe) {
                
            }
        }
		*/
        
        Random generator = new Random();
        int randomIndex = 0;
        int count = 0;
        
		randomIndex = generator.nextInt(3);                        
		switch(randomIndex){
            case 0:
            	mFillingGroup.check(R.id.bacon);
            	break;
            case 1:
            	mFillingGroup.check(R.id.pastrami);
            	break;
            default:
            	mFillingGroup.check(R.id.hummus);
            	break;                        		
		}
            
		randomIndex = generator.nextInt(2);
		switch(randomIndex){
            case 0:
            	mAddMayoCheckbox.setChecked(false);
            	break;
            default:
            	mAddMayoCheckbox.setChecked(true);
            	break;
		}
            
		randomIndex = generator.nextInt(2);
		switch(randomIndex){
            case 0:
            	mAddTomatoCheckbox.setChecked(false);
            	break;
            default:
            	mAddTomatoCheckbox.setChecked(true);
            	break;
		}                                         
            
		recordNewUIState();

        mFillingGroup.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
                    public void onCheckedChanged(RadioGroup group,
                            int checkedId) {
						recordNewUIState();
                    }
                });

        CompoundButton.OnCheckedChangeListener checkListener
                = new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView,
                    boolean isChecked) {
                recordNewUIState();
            }
        };
        mAddMayoCheckbox.setOnCheckedChangeListener(checkListener);
        mAddTomatoCheckbox.setOnCheckedChangeListener(checkListener);
    }


    
	void recordNewUIState() {

		AppData appd = new AppData(mAddMayoCheckbox.isChecked(), mAddTomatoCheckbox.isChecked(), mFillingGroup.getCheckedRadioButtonId());
        
        try {
            synchronized (sDataLock) {
                (adapt RWer).writeDataToFileLocked(appd);
            }
        } catch (IOException e) {
            Log.e(TAG, "Unable to record new UI state");
        }

        (adapt mBackupManager).dataChanged();
    }

								   
								   
								   
								   
	//////////////////////////////////////////////
	//////////////////////////////////////////////
	// Following is the battery status code
	//////////////////////////////////////////////
	//////////////////////////////////////////////
	static modeVT batteryState() {
		int level = (batteryIntent.getIntExtra("level", 0)) / 100;
		if (level > 0.4) return #hifi else return #lofi;
    }
			
	public static Intent batteryIntent = getApplicationContext().registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
								   
								   
								   
								   
								   
}


class AppData {

	AppData(int whichFilling, boolean addMayo, boolean addTomato) {
		this.whichFilling = whichFilling;
		this.addMayo = addMayo;
		this.addTomato = addTomato;
	}
	
    public int whichFilling;
	public boolean addMayo;
	public boolean addTomato;

}